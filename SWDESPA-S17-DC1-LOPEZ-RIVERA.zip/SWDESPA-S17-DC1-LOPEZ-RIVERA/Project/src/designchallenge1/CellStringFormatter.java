package designchallenge1;

public interface CellStringFormatter {
	public String format(int day, String eventString);
}
