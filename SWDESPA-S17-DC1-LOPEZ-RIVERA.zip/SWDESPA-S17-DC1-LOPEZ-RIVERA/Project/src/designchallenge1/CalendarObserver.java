package designchallenge1;

public interface CalendarObserver {
	public void update(CalendarEvent evt);
}
